from langgraph.prebuilt import create_react_agent
from langgraph.checkpoint.memory import MemorySaver
from langchain_groq import ChatGroq
from app.config import Config
from app.tools import get_tools

class MeetingSupervisor:
    # ADDED: model_name parameter with a default fallback
    def __init__(self, model_name="llama-3.3-70b-versatile"):
        
        # The true brain of the agent now uses the dynamic model_name
        self.llm = ChatGroq(
            temperature=0, 
            model_name=model_name, 
            api_key=Config.GROQ_API_KEY,
            max_retries=2
        )
        self.tools = get_tools()
        
        # Stateful memory checkpointer for multi-turn conversations
        self.memory = MemorySaver()
        
        # Upgraded System Prompt for Strict Citations
        self.system_prompt = """You are NeuralMeet, an elite AI Meeting Supervisor.
        Your goal is to extract precise, accurate information from meeting transcripts.
        ALWAYS use your retrieval tools to search for answers. 
        
        CRITICAL INSTRUCTION: You MUST provide citations for every factual claim. 
        When you retrieve information, look at the 'source' or 'document' metadata provided by the tool. 
        Append the source name at the end of your sentences like this: "The marketing budget was increased by 15% [Source: Q3_Board_Meeting.pdf]."
        
        If the tool does not return the answer, state clearly: "The current transcripts do not contain this information."
        Do not hallucinate. Provide concise, executive-level summaries."""

        # Added checkpointer to the agent
        self.agent = create_react_agent(
            self.llm, 
            self.tools, 
            prompt=self.system_prompt,
            checkpointer=self.memory
        )

    def get_executor(self):
        return self.agent