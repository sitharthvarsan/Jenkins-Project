import os
import pickle
import uuid
import hashlib
import json
from langchain_community.document_loaders import PyPDFLoader, Docx2txtLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.embeddings.fastembed import FastEmbedEmbeddings
from langchain_chroma import Chroma
from app.config import Config
from langchain_core.documents import Document

class DocumentIngestor:
    def __init__(self):
        self.embeddings = FastEmbedEmbeddings(model_name=Config.DENSE_MODEL)
        self.splitter = RecursiveCharacterTextSplitter(
            chunk_size=Config.CHUNK_SIZE, 
            chunk_overlap=Config.CHUNK_OVERLAP
        )
        os.makedirs(os.path.dirname(Config.BM25_PATH), exist_ok=True)
        
        # Path to store the cryptographic fingerprints of ingested files
        self.ledger_path = "ingestion_ledger.json"

    def is_duplicate_content(self, file_path: str) -> bool:
        """Generates a SHA-256 hash of the file and checks if it was already ingested."""
        hasher = hashlib.sha256()
        
        # Read the file in binary mode to calculate the hash
        with open(file_path, 'rb') as f:
            buf = f.read()
            hasher.update(buf)
        file_hash = hasher.hexdigest()
        
        # Load the ledger of previously seen hashes
        if os.path.exists(self.ledger_path):
            with open(self.ledger_path, 'r') as f:
                seen_hashes = json.load(f)
        else:
            seen_hashes = []
            
        # Check if we've seen this exact content before
        if file_hash in seen_hashes:
            return True 
            
        # If it's new, add it to the ledger and save
        seen_hashes.append(file_hash)
        with open(self.ledger_path, 'w') as f:
            json.dump(seen_hashes, f)
            
        return False

    def process_and_index(self, file_path, filename):
        try:
            file_ext = filename.split('.')[-1].lower()
            docs = []

            # --- UPDATED BACKEND ROUTING SWITCH ---
            if file_ext == "pdf":
                loader = PyPDFLoader(file_path)
                docs = loader.load()
                
            elif file_ext in ["doc", "docx"]:
                loader = Docx2txtLoader(file_path)
                docs = loader.load()
                
            elif file_ext == "json":
                with open(file_path, 'r', encoding='utf-8') as f:
                    json_data = json.load(f)
                
                formatted_text = json.dumps(json_data, indent=2)
                docs = [Document(page_content=formatted_text, metadata={"source": file_path})]

            # Ensure metadata is tagged correctly before chunking
            for i, doc in enumerate(docs):
                doc.metadata["source_file"] = filename
                doc.metadata["page"] = i + 1
                doc.metadata["chunk_id"] = str(uuid.uuid4())

            chunks = self.splitter.split_documents(docs)

            # 2. Index Dense Vectors locally in Chroma
            Chroma.from_documents(
                documents=chunks,
                embedding=self.embeddings,
                persist_directory=Config.CHROMA_DIR,
                collection_name="meeting_transcripts"
            )

            # 3. Store documents locally for BM25 Sparse Search
            # We append to existing docs if the file exists
            existing_docs = []
            if os.path.exists(Config.BM25_PATH):
                with open(Config.BM25_PATH, "rb") as f:
                    existing_docs = pickle.load(f)
            
            existing_docs.extend(chunks)
            with open(Config.BM25_PATH, "wb") as f:
                pickle.dump(existing_docs, f)

            return True, f"Indexed {len(chunks)} chunks into Chroma and BM25."
        except Exception as e:
            return False, f"Ingestion failed: {str(e)}"