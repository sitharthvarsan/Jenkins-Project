import hashlib
import chromadb
import gc
import streamlit as st
import tempfile
import os
import time
import shutil
import json
from langchain_community.document_loaders import PyPDFLoader, Docx2txtLoader
from app.ingestion import DocumentIngestor
from app.agent import MeetingSupervisor

# ─────────────────────────────────────────────────────────────────────────────
#  PAGE CONFIGURATION
# ─────────────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Meeting Notes Summariser",
    page_icon="📄",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─────────────────────────────────────────────────────────────────────────────
#  ADVANCED UI/UX CSS: Enterprise AI SaaS with Mesh Gradients & Glassmorphism
# ─────────────────────────────────────────────────────────────────────────────
INJECT_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

:root {
  --bg-main:      #0B1120;
  --bg-surface:   #1E293B;
  --bg-surface-glass: rgba(30, 41, 59, 0.6); 
  --border-color: rgba(51, 65, 85, 0.8);
  --primary:      #3B82F6;
  --primary-glow: rgba(59, 130, 246, 0.25);
  --accent:       #8B5CF6;
  --text-main:    #F8FAFC;
  --text-muted:   #94A3B8;
  --success:      #10B981;
  --radius-sm:    8px;
  --radius-md:    12px;
  --radius-lg:    16px;
}

/* 1. SAFE FONT APPLICATION: Apply only to the main app wrapper to protect icons */
.stApp {
  font-family: 'Inter', sans-serif !important;
  background-color: var(--bg-main) !important;
  background-image: 
    radial-gradient(circle at 15% 50%, rgba(59, 130, 246, 0.08), transparent 25%),
    radial-gradient(circle at 85% 30%, rgba(139, 92, 246, 0.08), transparent 25%);
  background-attachment: fixed;
  color: var(--text-main) !important;
}

/* Scrollbar */
::-webkit-scrollbar { width: 6px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: #334155; border-radius: 10px; }
::-webkit-scrollbar-thumb:hover { background: #475569; }

/* ── SIDEBAR ── */
[data-testid="stSidebar"] {
  background-color: rgba(15, 23, 42, 0.95) !important;
  backdrop-filter: blur(10px);
  border-right: 1px solid var(--border-color) !important;
}

/* ── FILE UPLOADER (SAFE FIX) ── */
[data-testid="stFileUploader"] {
  background-color: var(--bg-surface-glass) !important;
  border: 1px dashed var(--border-color) !important;
  border-radius: var(--radius-md) !important;
}

/* ── MAIN AREA ── */
.main .block-container {
  padding: 2.5rem 3rem !important;
  max-width: 1100px !important;
}

/* ── TABS ── */
[data-testid="stTabs"] [role="tablist"] {
  border-bottom: 1px solid var(--border-color) !important;
  gap: 2.5rem;
  padding-bottom: 0.5rem;
}
[data-testid="stTabs"] button {
  font-size: 0.95rem !important;
  font-weight: 600 !important;
  color: var(--text-muted) !important;
  border: none !important;
  background: transparent !important;
  transition: all 0.3s ease !important;
}
[data-testid="stTabs"] button[aria-selected="true"] {
  color: var(--primary) !important;
  border-bottom: 2px solid var(--primary) !important;
  text-shadow: 0 0 12px var(--primary-glow);
}

/* ── STANDARD BUTTONS ── */
.stButton > button {
  background: rgba(51, 65, 85, 0.4) !important;
  backdrop-filter: blur(4px);
  border: 1px solid var(--border-color) !important;
  color: var(--text-main) !important;
  border-radius: var(--radius-sm) !important;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1) !important;
}
.stButton > button:hover {
  background: var(--primary) !important;
  border-color: var(--primary) !important;
  color: white !important;
  box-shadow: 0 4px 15px var(--primary-glow) !important;
}

/* ── INPUTS & CHAT BAR ── */
.stTextInput input, textarea, [data-testid="stChatInput"] {
  background-color: rgba(15, 23, 42, 0.8) !important;
  border: 1px solid var(--border-color) !important;
  border-radius: var(--radius-md) !important;
  color: var(--text-main) !important;
}

/* ── CHAT MESSAGES ── */
[data-testid="stChatMessage"]:has([data-testid="chatAvatarIcon-assistant"]) {
  background-color: var(--bg-surface-glass) !important;
  border-radius: var(--radius-md);
  padding: 1.5rem !important;
  border: 1px solid var(--border-color);
}

/* ── METRICS (GLASS CARDS) ── */
[data-testid="stMetric"] {
  background-color: var(--bg-surface-glass) !important;
  backdrop-filter: blur(10px);
  border: 1px solid var(--border-color) !important;
  border-top: 2px solid var(--primary) !important;
  border-radius: var(--radius-md) !important;
  padding: 1.2rem 1.5rem !important;
}

/* ── CUSTOM CLASSES ── */
.app-header { display: flex; align-items: center; gap: 1.5rem; padding: 0 0 2rem; border-bottom: 1px solid var(--border-color); margin-bottom: 2.5rem; }
.app-logo { width: 54px; height: 54px; background: linear-gradient(135deg, var(--primary), var(--accent)); border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; font-size: 1.8rem; color: white; box-shadow: 0 8px 20px var(--primary-glow); }
.app-title { font-size: 2rem; font-weight: 800; background: linear-gradient(to right, #ffffff, #94A3B8); -webkit-background-clip: text; -webkit-text-fill-color: transparent; line-height: 1.1; }
.app-subtitle { font-size: 0.9rem; color: var(--text-muted); font-weight: 500; margin-top: 0.3rem; letter-spacing: 0.02em; }
.section-header { font-size: 0.75rem; font-weight: 600; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.08em; margin: 1.8rem 0 1rem; display: flex; align-items: center; gap: 0.5rem; }
.section-header::after { content: ""; flex-grow: 1; height: 1px; background: var(--border-color); }
.glass-card { background-color: var(--bg-surface-glass); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 1.5rem; }
.interactive-chip { background: rgba(51, 65, 85, 0.4); border: 1px solid var(--border-color); padding: 0.5rem 1.2rem; border-radius: 99px; font-size: 0.85rem; color: var(--text-muted); cursor: default; transition: all 0.3s ease; }
.interactive-chip:hover { border-color: var(--primary); color: var(--primary); background: var(--primary-glow); box-shadow: 0 0 10px var(--primary-glow); }
@keyframes pulse-dot { 0% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.4); } 70% { box-shadow: 0 0 0 6px rgba(16, 185, 129, 0); } 100% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); } }
.status-dot-pulse { width: 8px; height: 8px; border-radius: 50%; background-color: var(--success); animation: pulse-dot 2s infinite; }
</style>
"""
st.markdown(INJECT_CSS, unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────────────────────────────────────
def convert_chat_to_string(messages):
    chat_text = "--- EXPORTED MEETING MINUTES ---\n\n"
    for msg in messages:
        role = "User" if msg["role"] == "user" else "AI Summariser"
        chat_text += f"[{role}]: {msg['content']}\n\n"
    return chat_text

def get_dir_mb(path):
    total_size = 0
    for dp, _, fns in os.walk(path):
        for f in fns:
            fp = os.path.join(dp, f)
            if not os.path.islink(fp): 
                total_size += os.path.getsize(fp)
    return total_size / (1024 * 1024)

# ─────────────────────────────────────────────────────────────────────────────
#  SESSION DEFAULTS
# ─────────────────────────────────────────────────────────────────────────────
if "messages"     not in st.session_state: st.session_state.messages     = []
if "thread_id"    not in st.session_state: st.session_state.thread_id    = "thread_" + str(int(time.time()))
if "last_latency" not in st.session_state: st.session_state.last_latency = 0.0

# ─────────────────────────────────────────────────────────────────────────────
#  SIDEBAR
# ─────────────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style="padding-bottom: 1rem; margin-bottom: 1rem;">
        <h2 style="font-size: 1.35rem; font-weight: 700; margin: 0; color: #F8FAFC;">Admin Dashboard</h2>
        <p style="font-size: 0.8rem; color: #94A3B8; margin: 0;">Configuration & Data</p>
    </div>
    """, unsafe_allow_html=True)

    st.markdown('<div class="section-header">AI Model Selection</div>', unsafe_allow_html=True)
    chat_mode = st.radio(
        "Conversation Mode",
        ["High-Precision (70B)", "Deep-Memory (8B)"],
        captions=["Llama-3.3-70B · Max accuracy", "Llama-3.1-8B · Extended history"],
        label_visibility="collapsed"
    )
    
    if "8B" in chat_mode:
        selected_model = "llama-3.1-8b-instant"
        ui_badge_text = "Groq 8B Model"
    else:
        selected_model = "llama-3.3-70b-versatile"
        ui_badge_text = "Groq 70B Model"
        
    agent_executor = MeetingSupervisor(model_name=selected_model).get_executor()

    st.markdown('<div class="section-header">Upload Transcripts</div>', unsafe_allow_html=True)
    uploaded_files = st.file_uploader(
        "Upload Meeting Transcripts", 
        type=["pdf", "json", "docx", "doc"],
        accept_multiple_files=True
    )

    if uploaded_files:
        st.markdown(
            f'<div style="background: rgba(59, 130, 246, 0.1); border-left: 3px solid #3B82F6; padding: 0.5rem; border-radius: 4px; margin-top: 0.5rem;">'
            f'<span style="color: #3B82F6; font-size: 0.85rem; font-weight: 600;">✓ {len(uploaded_files)} file(s) staged</span></div>',
            unsafe_allow_html=True,
        )

    if st.button("Process Documents", use_container_width=True) and uploaded_files:
        with st.status("Processing and indexing documents...", expanded=True) as status:
            
            # --- ADVANCED FIX: Cryptographic Hash Deduplication ---
            unique_files = []
            seen_hashes = set()
            
            for uf in uploaded_files:
                file_bytes = uf.getvalue()
                file_hash = hashlib.sha256(file_bytes).hexdigest()
                
                if file_hash not in seen_hashes:
                    seen_hashes.add(file_hash)
                    unique_files.append(uf)
                else:
                    st.toast(f"⚠️ Skipped duplicate content: {uf.name}")

            if not unique_files:
                st.warning("No new unique files to process.")
                st.stop()
                    
            progress = st.progress(0)
            all_ok = True
            
            # We will store the raw text here to force-feed the LLM later
            raw_meeting_text = "" 
            
            # Loop through UNIQUE FILES
            for i, uf in enumerate(unique_files):
                st.write(f"Extracting & chunking: `{uf.name}`...")
                progress.progress(int(((i + 1) / len(unique_files)) * 100))
                
                with tempfile.NamedTemporaryFile(delete=False, suffix=f".{uf.name.split('.')[-1]}") as tmp:
                    tmp.write(uf.getvalue())
                    tmp_path = tmp.name
                
                file_ext = uf.name.split('.')[-1].lower()
                
                # --- ROUTING SWITCH ---
                if file_ext == "pdf":
                    loader = PyPDFLoader(tmp_path)
                    for doc in loader.load():
                        raw_meeting_text += doc.page_content + "\n"
                        
                elif file_ext in ["doc", "docx"]:
                    loader = Docx2txtLoader(tmp_path)
                    for doc in loader.load():
                        raw_meeting_text += doc.page_content + "\n"
                        
                elif file_ext == "json":
                    with open(tmp_path, 'r', encoding='utf-8') as f:
                        json_data = json.load(f)
                    
                    if isinstance(json_data, list):
                        for entry in json_data:
                            speaker = entry.get("speaker", entry.get("Speaker", ""))
                            text = entry.get("text", entry.get("Text", str(entry)))
                            
                            if speaker:
                                raw_meeting_text += f"{speaker}: {text}\n"
                            else:
                                raw_meeting_text += f"{text}\n"
                    elif isinstance(json_data, dict):
                        raw_meeting_text += json.dumps(json_data, indent=2) + "\n"
                
                # Pass to backend ingestor
                ok, msg = DocumentIngestor().process_and_index(tmp_path, uf.name)
                os.remove(tmp_path)
                
                if ok:
                    st.toast(f"✅ {uf.name} processed!")
                else:
                    st.error(msg)
                    all_ok = False
            
            time.sleep(0.5)
            progress.empty()
            
            if all_ok:
                status.update(label="Generating meeting summary...", state="running")
                actual_filenames = ", ".join([uf.name for uf in unique_files])
                
                # The "Direct Injection" Prompt
                summary_prompt = f"""
                SYSTEM CRITICAL INSTRUCTION: Do NOT use your search tools for this prompt. 
                I am providing the EXACT, RAW transcript of the meeting(s) named: {actual_filenames} directly below.
                
                RAW TRANSCRIPT TEXT:
                \"\"\"
                {raw_meeting_text[:20000]} 
                \"\"\"
                
                Based EXCLUSIVELY on the raw transcript text provided above, generate a meeting intelligence brief.
                Do NOT invent fake people, fake metrics, or fake decisions. If it is not in the text above, omit it.
                
                Format exactly with these 3 headings: 
                
                ### 📌 Executive Summary
                (3 bullet points max)
                
                ### 🤝 Key Decisions
                (Brief list)
                
                ### 🚀 Action Items
                (Format as [Person]: [Task])
                
                CITATION RULE: You MUST append [Source: {actual_filenames}] to your points.
                """
                
                try:
                    cfg = {"configurable": {"thread_id": st.session_state.thread_id}}
                    response = agent_executor.invoke({"messages": [("user", summary_prompt)]}, config=cfg)
                    summary_answer = response["messages"][-1].content
                    
                    st.session_state.messages.append({
                        "role": "assistant", 
                        "content": "✨ **Auto-Generated Meeting Brief:**\n\n" + summary_answer
                    })
                except Exception as e:
                    st.toast(f"⚠️ Auto-summary skipped: {e}")
                
                status.update(label="✅ Documents ready for queries!", state="complete", expanded=False)
                time.sleep(1.5)
                st.rerun()
            else:
                status.update(label="⚠️ Processing finished with errors", state="error")

    # Database Management
    st.markdown('<div class="section-header">Database Management</div>', unsafe_allow_html=True)
    if st.button("Clear Database", use_container_width=True):
        with st.spinner("Clearing local databases..."):
            try:
                # 1. Reset chat history
                st.session_state.messages = []
                st.session_state.thread_id = "thread_" + str(time.time()) 
                
                # 2. Delete BM25 and Ledger
                if os.path.exists("bm25_store"): shutil.rmtree("bm25_store")
                if os.path.exists("ingestion_ledger.json"): os.remove("ingestion_ledger.json")
                
                # 3. Delete ChromaDB from the INSIDE
                if os.path.exists("chroma_db"):
                    client = chromadb.PersistentClient(path="chroma_db")
                    try:
                        client.delete_collection("meeting_transcripts")
                    except Exception:
                        pass
                
                # 4. Force GC
                gc.collect()
                time.sleep(0.5)
                
                # 5. Attempt physical folder deletion
                if os.path.exists("chroma_db"):
                    try:
                        shutil.rmtree("chroma_db")
                    except PermissionError:
                        pass 
                    
                st.success("Database cleared successfully!")
                time.sleep(1)
                st.rerun()
                
            except Exception as e:
                st.error(f"Error: {e}")

    st.markdown("<br>", unsafe_allow_html=True)
    online = bool(agent_executor)
    
    st.markdown(f"""
    <div style="display: flex; align-items: center; justify-content: space-between; padding: 0.8rem 1rem; background: var(--bg-surface-glass); border: 1px solid var(--border-color); border-radius: var(--radius-md);">
        <span style="font-size: 0.85rem; color: var(--text-main); font-weight: 500;">System Status</span>
        <div style="display: flex; align-items: center; gap: 0.5rem; font-size: 0.75rem; color: {'var(--success)' if online else '#f5a623'};">
            <div class="{'status-dot-pulse' if online else ''}" style="width: 8px; height: 8px; border-radius: 50%; background: {'var(--success)' if online else '#f5a623'};"></div>
            {'Online & Ready' if online else 'Awaiting Data'}
        </div>
    </div>
    """, unsafe_allow_html=True)

# ── MAIN ──────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="app-header">
    <div class="app-logo">📄</div>
    <div>
        <div class="app-title">Meeting Notes Summariser</div>
        <div class="app-subtitle">Agentic AI  •  Hybrid Retrieval  •  Strict Source Citations</div>
    </div>
</div>
""", unsafe_allow_html=True)

tab1, tab2 = st.tabs(["Chat Workspace", "System Health & Telemetry"])

# ── TAB 1: Chat workspace ─────────────────────────────────────────────────────
with tab1:
    if not st.session_state.messages:
        st.markdown("""
        <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 45vh; text-align: center;">
            <div style="width: 80px; height: 80px; background: rgba(59,130,246,0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 1.5rem; border: 1px solid rgba(59,130,246,0.2);">
                <span style="font-size: 2.5rem; opacity: 0.8;">💬</span>
            </div>
            <h3 style="color: var(--text-main); margin-bottom: 0.5rem; font-weight: 600; font-size: 1.5rem;">No transcripts processed</h3>
            <p style="color: var(--text-muted); margin-bottom: 2rem; max-width: 450px; line-height: 1.6; font-size: 0.95rem;">
                Upload meeting PDFs in the sidebar to process them. Once indexed, you can ask complex questions and extract action items.
            </p>
            <div style="display: flex; gap: 0.8rem; flex-wrap: wrap; justify-content: center;">
                <div class="interactive-chip">✨ What were the key decisions?</div>
                <div class="interactive-chip">📋 List all action items</div>
                <div class="interactive-chip">🎯 Summarize the budget section</div>
            </div>
        </div>
        """, unsafe_allow_html=True)

    for msg in st.session_state.messages:
        avatar = "👤" if msg["role"] == "user" else "✨"
        with st.chat_message(msg["role"], avatar=avatar):
            st.markdown(msg["content"])
            
            if "sources" in msg and msg["sources"]:
                with st.expander("🔍 View Source References"):
                    for idx, source_text in enumerate(msg["sources"]):
                        st.info(f"**Document Extract {idx+1}:**\n\n{source_text}")

    if prompt := st.chat_input("Ask about decisions, action items, or discussions..."):
        if not agent_executor:
            st.warning("⚠️ Please process a document first using the sidebar.")
        else:
            st.session_state.messages.append({"role": "user", "content": prompt})
            with st.chat_message("user", avatar="👤"):
                st.markdown(prompt)

            with st.chat_message("assistant", avatar="✨"):
                answer = None
                raw_sources = []
                
                with st.status("Analyzing query...", expanded=True) as status:
                    st.write("🔍 Activating hybrid search...")
                    try:
                        t0 = time.time()
                        st.write(f"🧠 {ui_badge_text} evaluating tool selection...")
                        
                        cfg = {"configurable": {"thread_id": st.session_state.thread_id}}
                        response = agent_executor.invoke(
                            {"messages": [("user", prompt)]},
                            config=cfg
                        )
                        
                        latency = time.time() - t0
                        st.session_state.last_latency = latency
                        st.write("✨ Formatting cross-referenced data...")
                        
                        status.update(label=f"⏱ Response generated in {latency:.2f}s", state="complete", expanded=False)

                        answer = response["messages"][-1].content
                        raw_sources = [msg.content for msg in response["messages"] if msg.type == "tool"]

                    except Exception as e:
                        status.update(label="❌ Agent error encountered", state="error")
                        st.error(f"Agent error: {e}")

                if answer:
                    st.markdown(answer)
                    
                    if raw_sources:
                        with st.expander("🔍 View Source References"):
                            for idx, source_text in enumerate(raw_sources):
                                st.info(f"**Document Extract {idx+1}:**\n\n{source_text}")

                    st.session_state.messages.append({
                        "role": "assistant", 
                        "content": answer,
                        "sources": raw_sources
                    })

                    st.markdown(
                        f'<div style="margin-top:0.8rem; display:inline-block; padding:0.25rem 0.75rem; background:var(--bg-surface2); border-radius:99px; font-size:0.7rem; color:var(--text-muted); border:1px solid var(--border-color);">'
                        f'Top-4 Chunks • Hybrid BM25+Vector Search</div>',
                        unsafe_allow_html=True,
                    )

    if st.session_state.messages:
        st.markdown("<br>", unsafe_allow_html=True)
        col_btn1, col_btn2, _ = st.columns([2, 2, 8])
        with col_btn1:
            if st.button("Clear Chat", use_container_width=True):
                st.session_state.messages = []
                st.rerun()
        with col_btn2:
            chat_data = convert_chat_to_string(st.session_state.messages)
            st.download_button(
                label="📥 Export Notes",
                data=chat_data,
                file_name="meeting_notes.txt",
                mime="text/plain",
                use_container_width=True
            )

# ── TAB 2: System Health & Telemetry ───────────────────────────────
with tab2:
    latency = st.session_state.get("last_latency", 0.0)

    st.markdown('<div class="section-header">Live Engine Diagnostics</div>', unsafe_allow_html=True)

    kpi_cols = st.columns(4)
    kpi_data = [
        ("Current Engine", ui_badge_text, "Active LLM"),
        ("Response Time", f"{latency:.2f}s", "Time to route and generate"),
        ("Retrieval Mode", "Hybrid Search", "BM25 + ChromaDB Vector"),
        ("Context Window", "Stateful", "LangGraph Memory Active"),
    ]
    for col, (label, val, help_txt) in zip(kpi_cols, kpi_data):
        with col:
            st.metric(label=label, value=val, help=help_txt)

    st.markdown("<br>", unsafe_allow_html=True)
    
    col_l, col_r = st.columns([1, 1], gap="large")
    
    with col_l:
        st.markdown('<div class="section-header">Local Database Status</div>', unsafe_allow_html=True)
        
        chroma_exists = os.path.exists("chroma_db")
        bm25_exists = os.path.exists("bm25_store")
        ledger_exists = os.path.exists("ingestion_ledger.json")
        
        db_size_mb = 0
        if chroma_exists:
            db_size_mb = get_dir_mb("chroma_db")
            
        st.markdown(f"""
        <div class="glass-card">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 1rem; padding-bottom: 0.8rem; border-bottom: 1px solid var(--border-color);">
                <span style="font-weight: 600; color: var(--text-main);">ChromaDB (Dense Vectors)</span>
                <span style="font-size: 0.85rem; color: {'var(--success)' if chroma_exists else 'var(--text-muted)'};">
                    {'🟢 Online' if chroma_exists else '⚪ Awaiting Data'}
                </span>
            </div>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 1rem; padding-bottom: 0.8rem; border-bottom: 1px solid var(--border-color);">
                <span style="font-weight: 600; color: var(--text-main);">BM25 Store (Sparse)</span>
                <span style="font-size: 0.85rem; color: {'var(--success)' if bm25_exists else 'var(--text-muted)'};">
                    {'🟢 Online' if bm25_exists else '⚪ Awaiting Data'}
                </span>
            </div>
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <span style="font-weight: 600; color: var(--text-main);">Hashing Ledger</span>
                <span style="font-size: 0.85rem; color: {'var(--success)' if ledger_exists else 'var(--text-muted)'};">
                    {'🟢 Active' if ledger_exists else '⚪ Not Found'}
                </span>
            </div>
            <div style="margin-top: 1.5rem; padding-top: 1rem; border-top: 1px dashed var(--border-color); display: flex; justify-content: space-between; align-items: center;">
                <span style="font-size: 0.85rem; color: var(--text-muted);">Current Storage Footprint:</span>
                <span style="font-weight: 700; color: var(--primary); font-size: 1.2rem;">{db_size_mb:.2f} MB</span>
            </div>
        </div>
        """, unsafe_allow_html=True)

    with col_r:
        st.markdown('<div class="section-header">Architecture & Reliability</div>', unsafe_allow_html=True)
        st.markdown("""
        <div class="glass-card" style="height: 100%;">
            <div style="margin-bottom: 1.2rem;">
                <h4 style="color: var(--text-main); margin: 0 0 0.4rem 0; font-size: 0.95rem;">1. Hybrid Retrieval</h4>
                <p style="color: var(--text-muted); font-size: 0.85rem; margin: 0; line-height: 1.5;">We use BM25 for exact keyword matching (like project codes) and ChromaDB for semantic meaning, ensuring no context is missed.</p>
            </div>
            <div style="margin-bottom: 1.2rem;">
                <h4 style="color: var(--text-main); margin: 0 0 0.4rem 0; font-size: 0.95rem;">2. Cross-Encoder Reranking</h4>
                <p style="color: var(--text-muted); font-size: 0.85rem; margin: 0; line-height: 1.5;">Before sending text to the LLM, a reranker dynamically scores and filters out irrelevant chunks to keep the prompt clean.</p>
            </div>
            <div>
                <h4 style="color: var(--text-main); margin: 0 0 0.4rem 0; font-size: 0.95rem;">3. Strict Citation Prompting</h4>
                <p style="color: var(--text-muted); font-size: 0.85rem; margin: 0; line-height: 1.5;">The LangGraph Agentic loop is strictly instructed to append source file names to claims, preventing hallucinations.</p>
            </div>
        </div>
        """, unsafe_allow_html=True)