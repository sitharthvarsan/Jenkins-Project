import streamlit as st
import tempfile
import os
import time
from app.ingestion import DocumentIngestor
from app.agent import MeetingSupervisor
from app.evaluation import RAGEvaluator

st.set_page_config(page_title="Agentic Transcript AI", layout="wide")

# Initialize Agent
agent_executor = MeetingSupervisor().get_executor()

# --- SIDEBAR ---
with st.sidebar:
    st.header("📄 Ingestion Pipeline")
    uploaded_file = st.file_uploader("Upload Transcript (PDF)", type=["pdf"])
    
    if st.button("Index Document") and uploaded_file:
        with st.spinner("Chunking & embedding (Local Dense + Sparse)..."):
            with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
                tmp.write(uploaded_file.getvalue())
                tmp_path = tmp.name
            
            success, msg = DocumentIngestor().process_and_index(tmp_path, uploaded_file.name)
            os.remove(tmp_path)
            
            if success:
                st.success(msg)
                st.rerun() # Refresh to load tools
            else:
                st.error(msg)
                
    st.divider()
    status = "🟢 Online" if agent_executor else "🟡 Awaiting Data"
    st.info(f"System Status: {status}\n\nStack: Groq 70B + Chroma + BM25")

# --- MAIN TABS ---
tab1, tab2 = st.tabs(["💬 Workspace", "📊 Evaluation"])

with tab1:
    st.title("Meeting Intelligence Workspace")
    
    if "messages" not in st.session_state:
        st.session_state.messages = []

    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    if prompt := st.chat_input("E.g., What were the final decisions on the Q3 budget?"):
        if not agent_executor:
            st.warning("Please upload a document first.")
        else:
            st.session_state.messages.append({"role": "user", "content": prompt})
            with st.chat_message("user"):
                st.markdown(prompt)

            with st.chat_message("assistant"):
                with st.spinner("Supervisor routing query & reranking..."):
                    try:
                        start_time = time.time()
                        inputs = {"messages": [("user", prompt)]}
                        response = agent_executor.invoke(inputs)
                        latency = time.time() - start_time
                        
                        st.session_state.last_latency = latency # Save for eval tab
                        
                        final_answer = response["messages"][-1].content
                        st.markdown(final_answer)
                        st.session_state.messages.append({"role": "assistant", "content": final_answer})
                    except Exception as e:
                        st.error(f"API/Agent Error: {str(e)}")

with tab2:
    st.title("Performance & Metrics")
    st.markdown("Automated QA tracking context accuracy and hallucination rates.")
    
    latency = st.session_state.get("last_latency", 0.0)
    df, _ = RAGEvaluator.get_mock_metrics(latency)
    
    col1, col2 = st.columns([1, 2])
    with col1:
        st.dataframe(df, use_container_width=True)
        st.metric(label="Last Query Latency", value=f"{latency:.2f}s")
        st.metric(label="Token Usage Tracking", value="Optimized (Top 4 Chunks)")
        
    with col2:
        fig = RAGEvaluator.render_charts(df)
        st.plotly_chart(fig, use_container_width=True)