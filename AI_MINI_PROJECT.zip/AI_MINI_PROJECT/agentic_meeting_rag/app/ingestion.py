import os
import pickle
import uuid
from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.embeddings.fastembed import FastEmbedEmbeddings
from langchain_chroma import Chroma
from app.config import Config

class DocumentIngestor:
    def __init__(self):
        self.embeddings = FastEmbedEmbeddings(model_name=Config.DENSE_MODEL)
        self.splitter = RecursiveCharacterTextSplitter(
            chunk_size=Config.CHUNK_SIZE, 
            chunk_overlap=Config.CHUNK_OVERLAP
        )
        os.makedirs(os.path.dirname(Config.BM25_PATH), exist_ok=True)

    def process_and_index(self, file_path: str, filename: str):
        try:
            loader = PyPDFLoader(file_path)
            docs = loader.load()
            
            # Robust Metadata Injection
            for i, doc in enumerate(docs):
                doc.metadata["source_file"] = filename
                doc.metadata["page"] = i + 1
                doc.metadata["chunk_id"] = str(uuid.uuid4())

            chunks = self.splitter.split_documents(docs)

            # 1. Index Dense Vectors locally in Chroma
            Chroma.from_documents(
                documents=chunks,
                embedding=self.embeddings,
                persist_directory=Config.CHROMA_DIR,
                collection_name="meeting_transcripts"
            )

            # 2. Store documents locally for BM25 Sparse Search
            # We append to existing docs if the file exists
            existing_docs = []
            if os.path.exists(Config.BM25_PATH):
                with open(Config.BM25_PATH, "rb") as f:
                    existing_docs = pickle.load(f)
            
            existing_docs.extend(chunks)
            with open(Config.BM25_PATH, "wb") as f:
                pickle.dump(existing_docs, f)

            return True, f"Indexed {len(chunks)} chunks into Chroma and BM25."
        except Exception as e:
            return False, f"Ingestion failed: {str(e)}"