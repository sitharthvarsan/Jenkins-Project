import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    GROQ_API_KEY = os.getenv("GROQ_API_KEY")
    DENSE_MODEL = "BAAI/bge-small-en-v1.5"
    CHROMA_DIR = "./chroma_db"
    BM25_PATH = "./bm25_store/bm25_docs.pkl"
    CHUNK_SIZE = 700
    CHUNK_OVERLAP = 100