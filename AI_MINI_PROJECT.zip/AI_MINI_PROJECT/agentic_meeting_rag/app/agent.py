from langgraph.prebuilt import create_react_agent
from langchain_groq import ChatGroq
from app.config import Config
from app.tools import get_tools

class MeetingSupervisor:
    def __init__(self):
        self.llm = ChatGroq(
            temperature=0, 
            model_name="llama3-70b-8192", 
            api_key=Config.GROQ_API_KEY,
            max_retries=2
        )
        
        self.system_prompt = """You are a Principal Executive Assistant.
        Your goal is to extract factual information from meeting transcripts using your tools.
        
        CRITICAL RULES:
        1. STRICT GROUNDING: If the tools return no context, reply ONLY with: "I could not find information regarding this in the provided transcripts." Do NOT guess.
        2. STRUCTURE: Format your output cleanly using markdown bullet points.
        3. MANDATORY CITATIONS: Every bullet point MUST end with a citation identifying the source document and page. 
           Format: `[Source: {filename}, Page: {page}]`. Extract this from the chunk metadata.
        """

    def get_executor(self):
        tools = get_tools()
        if not tools:
            return None # DB not ready
            
        return create_react_agent(
            model=self.llm,
            tools=tools,
            state_modifier=self.system_prompt
        )