import os
import pickle
from langchain_community.embeddings.fastembed import FastEmbedEmbeddings
from langchain_chroma import Chroma
from langchain_community.retrievers import BM25Retriever
from langchain.retrievers import EnsembleRetriever
from langchain.retrievers.contextual_compression import ContextualCompressionRetriever
from langchain.retrievers.document_compressors import FlashrankRerank
from langchain.tools.retriever import create_retriever_tool
from app.config import Config

def get_hybrid_reranked_retriever():
    """Builds the Ensemble (Chroma + BM25) and wraps it in FlashRank."""
    if not os.path.exists(Config.BM25_PATH):
        raise ValueError("No documents indexed yet. Please upload a PDF first.")

    # 1. Dense Retriever
    embeddings = FastEmbedEmbeddings(model_name=Config.DENSE_MODEL)
    db = Chroma(persist_directory=Config.CHROMA_DIR, embedding_function=embeddings, collection_name="meeting_transcripts")
    dense_retriever = db.as_retriever(search_kwargs={"k": 10})

    # 2. Sparse Retriever
    with open(Config.BM25_PATH, "rb") as f:
        docs = pickle.load(f)
    sparse_retriever = BM25Retriever.from_documents(docs)
    sparse_retriever.k = 10

    # 3. Ensemble Fusion
    ensemble = EnsembleRetriever(
        retrievers=[dense_retriever, sparse_retriever], 
        weights=[0.5, 0.5] # 50/50 weighting strategy
    )

    # 4. Reranking Layer (Token Reduction)
    compressor = FlashrankRerank(top_n=4)
    return ContextualCompressionRetriever(base_compressor=compressor, base_retriever=ensemble)

def get_tools():
    try:
        retriever = get_hybrid_reranked_retriever()
    except ValueError:
        return [] # Return empty if no DB exists yet

    return [
        create_retriever_tool(
            retriever,
            "search_general_meeting_notes",
            "Searches general meeting context, quotes, and discussions."
        ),
        create_retriever_tool(
            retriever,
            "extract_action_items",
            "Searches specifically for tasks, owners, and deadlines mentioned in meetings."
        ),
        create_retriever_tool(
            retriever,
            "extract_decisions",
            "Searches specifically for final decisions, approvals, or strategic pivots."
        )
    ]